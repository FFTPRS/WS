有限体理論とその擬似乱数系列生成への応用ワークショップ(FFTPRS)予稿集 Author's Kit

*** 内容 ***
readme.txt: このファイル
instruction.tex: 原稿作成・投稿要項(LaTeX source)
instruction.pdf: 原稿作成・投稿要項(PDF)
e-template.tex: 英文用 原稿 テンプレート
j-template.tex: 和文用 原稿 テンプレート
fftprsws.sty: 和文英文兼用 原稿 スタイルファイル
              (LaTeX2eおよびLaTeX 2.09兼用)

---

# end of file
